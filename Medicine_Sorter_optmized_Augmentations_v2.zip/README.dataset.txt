# Medicine Sorter > Optimized with Augmentations
https://universe.roboflow.com/nypdeeplearning/medicine-sorter-2lnno-tpgns

Provided by a Roboflow user
License: CC BY 4.0

