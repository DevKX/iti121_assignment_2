# Medicine Sorter > Augmented
https://universe.roboflow.com/nypdeeplearning/medicine-sorter-2lnno-tpgns

Provided by a Roboflow user
License: CC BY 4.0

